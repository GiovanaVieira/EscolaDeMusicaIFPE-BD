import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class PecaLInvertida here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PecaLInvertida extends Peca{
    private Bloco[] bloco;
    
    //Cria uma peça em um local aleatório da primeira linha do mundo
    void criaPecaLocalAleatório(){
    
    }
    
    //Adiciona a peça ao mundo
    void criarPecaNoMundo(){
    
    }
    
    //Muda a direção da peça
    void mudarDirecao(){
    
    }
    
    //Verifica se pode girar a peça
    protected boolean girarPeca(){
        return true;
    }
    
    protected Bloco blocoDireito(){
        return bloco[0];
    }
    
    protected Bloco blocoEsquerdo(){
        return bloco[3];
    }
}
