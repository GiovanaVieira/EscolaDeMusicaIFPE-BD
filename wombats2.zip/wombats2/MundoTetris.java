import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MundoTetris here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MundoTetris extends World{ 
    private static MundoTetris mundo;
    private int numeroPecas;

    /**
     * Constructor for objects of class MundoTetris.
     * 
     */
    public MundoTetris()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(270, 500, 1); 

        prepare();
    }

    //Cria uma peça aleatória ao mundo
    Peca criaPecaAleatoria(){
        this.numeroPecas += 1; 

        int NumeroAleatorio;
        NumeroAleatorio = Greenfoot.getRandomNumber(7);

        switch(NumeroAleatorio){
            case 0:
            return new PecaI();        
            case 1:
            return new PecaZInvertida();
            case 2:
            return new PecaL();
            case 3:
            return new PecaZ();
            case 4:
            return new PecaQuadrado();
            case 5:
            return new PecaLInvertida();
            default:
            return new PecaT();
        }
    }

    //Retorna o mundo (não estava conseguindo acessar métodos do mundo diretamente)
    static MundoTetris retornaMundoTetris(){
        return mundo;
    }

    //Mostra o placar do jogo e para de rodar o jogo
    void fimDeJogo(){
        Greenfoot.stop();
    }

    /**
     * Prepare the world for the start of the program. That is: create the initial
     * objects and add them to the world.
     */
    private void prepare()
    {
    }
}
