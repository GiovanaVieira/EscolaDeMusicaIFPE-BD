import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bloco here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bloco extends Actor{
    //Aplica uma imagem para o bloco
    Bloco(){
        setImage("cell.png");
    }
}