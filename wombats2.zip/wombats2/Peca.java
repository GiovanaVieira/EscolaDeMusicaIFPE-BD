import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class PEca here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public abstract class Peca extends Actor{
    private Bloco[] bloco;
    private boolean blocoParado;
    
    //verifica quais teclas o usuário pressionou e faz uma ação definida
    public void act(){
        if(Greenfoot.isKeyDown("Up")){
        
        } 
        if(Greenfoot.isKeyDown("Down")){
        
        }
        if(Greenfoot.isKeyDown("Left")){
        
        }
        if(Greenfoot.isKeyDown("Right")){
        
        }
    }
    
    
    
    //Verifica se a coluna da direita está ocupada
    boolean colunaDireitaOcupada(){
        Bloco bloco = new Bloco();
        if(blocoDireito().getX() + 1 == bloco.getWorld().getWidth() ){
            return true;
        }
        return false;
    }
    
    //Verifica se a coluna da esquerda está ocupada
    boolean colunaEsquerdaOcupada(){
        Bloco bloco = new Bloco();
        if(blocoEsquerdo().getX() == 0){
            return true;
        }        
        return false;
    }
    
    //Movimenta a peca para a direita, em 1 coluna
    void moverParaDireita(){
        int auxiliar;
        if(colunaDireitaOcupada() == true){
            return;
        }
        
        for(auxiliar = 0; auxiliar < 4; auxiliar++){
            bloco[auxiliar].setLocation(bloco[auxiliar].getX(), bloco[auxiliar].getY() - 1);
        }
    }
    
    //Movimenta a peça para a esquerda, em 1 coluna
    void moverParaEsquerda(){
        int auxiliar;
        if(colunaEsquerdaOcupada() == true){
            return;
        }
        
        for(auxiliar = 0; auxiliar < 4; auxiliar++){
            bloco[auxiliar].setLocation(bloco[auxiliar].getX() - 1, bloco[auxiliar].getY());
        }
    }
    
    //Ação de girar a peça do tetris
    abstract boolean girarPeca();
    
    //Verifica qual é o bloco mais a esquerda da peça
    abstract Bloco blocoEsquerdo();
    
    //Verifica qual é o bloco mais a direita da peça
    abstract Bloco blocoDireito();
    
    void descerUmaLinha(){
        if(blocoAbaixoLivre() == false){
            return;
        }
        
        
    }
    //Verifica se  a linha abaixo do bloco está livre
    boolean blocoAbaixoLivre(){  
    //    if bloco.getX
        return true;
    }
    
    //Verifica se alguma linha do mundo foi preenchida com blocos
    void linhaCompletada(){
    
    }
    
    //Elimina uma linha completada por blocos no mundo
    void limparLinhaCompletada(){
    
    }
    
    //Caso a peça encontre uma bloco abaixo e não possa se movimentar, ela para.
    void paraPeca(){
        MundoTetris mundo = MundoTetris.retornaMundoTetris();
        
        Peca peca = mundo.criaPecaAleatoria();
        if(fimDoCenario(peca) == true){
        
        }
    
    }
    
    //Deleta uma peça criada no Mundo
    void deletaPeca(){
        int auxiliar;
        for(auxiliar = 0; auxiliar < 4; auxiliar++){
            getWorld().removeObject(bloco[auxiliar]);
        }
        blocoParado = true;
    }
    
    //Verifica se o fim do mundo foi alcançado, se sim, cria outra peça.
    boolean fimDoCenario(Peca peca){
        
        return false;
    }
}
