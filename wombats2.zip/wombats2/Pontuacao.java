/**
 * Write a description of class Pontuacao here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Pontuacao  {

    /**
     * Constructor for objects of class Pontuacao
     */
    public Pontuacao(){
        
    }
    
    int pegarPontos(){
   
    return 0;
    }
}
