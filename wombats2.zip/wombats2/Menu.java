import greenfoot.*;

/**
 * Write a description of class Menu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Menu extends World
{

    /**
     * Constructor for objects of class Menu.
     * 
     */
    public Menu()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(250, 530, 1); 

        prepare();
    }

    /**
     * Prepare the world for the start of the program. That is: create the initial
     * objects and add them to the world.
     */
    private void prepare()
    {
        tetris tetris = new tetris();
        addObject(tetris, 170, 40);
        start start = new start();
        addObject(start, 43, 336);
        novojogo novojogo = new novojogo();
        addObject(novojogo, 240, 454);
        novojogo.setLocation(234, 449);
        novojogo.setLocation(191, 424);
        start start2 = new start();
        addObject(start2, 202, 340);
        start2.setLocation(194, 333);
        novojogo.setLocation(216, 315);
        novojogo novojogo2 = new novojogo();
        addObject(novojogo2, 213, 423);
        removeObject(novojogo2);
        removeObject(novojogo);
        novojogo novojogo3 = new novojogo();
        addObject(novojogo3, 209, 320);
        novojogo3.setLocation(224, 315);
        novojogo3.setLocation(219, 314);
        novojogo3.setLocation(219, 245);
        novojogo3.setLocation(215, 71);
        start.setLocation(33, 336);
        start2.setLocation(207, 334);
        novojogo3.setLocation(203, 217);
        novojogo3.setLocation(212, 311);
        novojogo3.setLocation(211, 314);
        novojogo3.setLocation(107, 280);
        novojogo3.setLocation(207, 314);
        novojogo3.setLocation(125, 317);
        novojogo3.setLocation(62, 312);
        novojogo3.setLocation(161, 70);
        start2.setLocation(209, 334);
        novojogo3.setLocation(161, 70);
        novojogo3.setLocation(161, 70);
        novojogo3.setLocation(161, 70);
        novojogo3.setLocation(161, 70);
        novojogo3.setLocation(161, 70);
        novojogo3.setLocation(161, 70);
        novojogo3.setLocation(161, 70);
        novojogo3.setLocation(161, 70);
        novojogo3.setLocation(161, 70);
        novojogo3.setLocation(161, 70);
        novojogo3.setLocation(224, 316);
        novojogo3.setLocation(209, 312);
        novojogo3.setLocation(214, 79);
        start.setLocation(32, 335);
        novojogo3.setLocation(209, 312);
        novojogo3.setLocation(101, 335);
        removeObject(novojogo3);
        novojogo novojogo4 = new novojogo();
        addObject(novojogo4, 126, 341);
        novojogo4.setLocation(121, 336);
    }

}
